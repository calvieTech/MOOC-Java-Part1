public class Greeter {

    public static void main(String[] args) {
        // Write your code here
	System.out.println("Hello world!");
	System.out.println("(And all the people of the world)");
    }

}
