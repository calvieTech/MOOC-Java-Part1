public class Multiplication {

    public static void main(String[] args) {

        int a = 1337;
        int b = 42;
        int multiply = a * b;
        // Program your solution here. Remember to use variables a and b!
        System.out.println(a + " * " + b + " = " + multiply );
    }

}
